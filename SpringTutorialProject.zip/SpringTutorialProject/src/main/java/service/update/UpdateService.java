package service.update;

public interface UpdateService {
}
