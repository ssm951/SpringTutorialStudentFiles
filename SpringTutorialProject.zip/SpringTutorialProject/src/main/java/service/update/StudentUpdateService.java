package service.update;

public class StudentUpdateService implements UpdateService {
}
