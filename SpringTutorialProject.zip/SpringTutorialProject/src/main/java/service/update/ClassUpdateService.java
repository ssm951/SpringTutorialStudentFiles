package service.update;

public class ClassUpdateService implements UpdateService {
}
